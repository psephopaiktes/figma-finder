interface Store {
  access_token: string;
  teams: Record<string, string>;
}

export const store: Store = {
  access_token: "figu_lmTZVdxe6_Tjc-jNHoBUHizpiDt7wgYgKH9-NY5i",
  teams: {
    "1470280501784377754": "CraftaBank office",
    "869378570433168571": "U-NEXT",
  },
};
