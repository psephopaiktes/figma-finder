<script lang="ts">
  import { state } from "./lib/state.svelte";
  import { fetchTeamProjects, fetchProjectFiles } from "./lib/api";
  import { getCachedData, setCachedData } from "./lib/cache";
  import { getCachedDataWithExpiry, setCachedDataWithTimestamp } from "./lib/cache";

  let query = "";
  let results = [];
  let error = "";
  let isLoading = false;
  let debounceTimer;

  async function loadAllFiles() {
    error = "";
    isLoading = true;
    try {
      // Check cache with expiry (1 hour)
      const cachedFiles = await getCachedDataWithExpiry("allFiles", 3600000);
      if (cachedFiles) {
        console.log("Loaded files from cache:", cachedFiles);
        state.files = cachedFiles;
        isLoading = false;
        return;
      }

      // Fetch and set teams
      const teams = [
        { id: "1470280501784377754", name: "CraftaBank office" },
        { id: "869378570433168571", name: "U-NEXT" },
      ];
      state.teams = teams;

      const allFiles = [];
      for (const team of teams) {
        const projects = await fetchTeamProjects(team.id);
        for (const project of projects) {
          const files = await fetchProjectFiles(project.id);
          allFiles.push({ teamName: team.name, projectName: project.name, files });
        }
      }

      console.log("Fetched all files:", allFiles);
      state.files = allFiles;

      // Save to cache with timestamp
      await setCachedDataWithTimestamp("allFiles", allFiles);
      console.log("Saved files to cache");
    } catch (err) {
      error = err.message;
      console.error("Error in loadAllFiles:", err);
    } finally {
      isLoading = false;
    }
  }

  function debounceSearch(callback, delay) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(callback, delay);
  }

  $: loadAllFiles();

  $: debounceSearch(() => {
    results = state.files
      .flatMap(({ teamName, projectName, files }) =>
        files.map((file) => ({
          ...file,
          teamName,
          projectName,
        }))
      )
      .filter((file) => file.name.toLowerCase().includes(query.toLowerCase()));

    if (results.length === 0 && query.trim() !== "") {
      console.log("No results found in cache. Fetching from API...");
      loadAllFiles();
    }
  }, 300);
</script>

<main>
  <h1>Figma File Finder</h1>
  <input
    type="text"
    bind:value={query}
    placeholder="Search for Figma files..."
  />

  {#if isLoading}
    <p>Loading...</p>
  {/if}

  {#if error}
    <p style="color: red;">{error}</p>
  {/if}

  {#if results.length > 0}
    {#each results as { teamName, projectName, name, thumbnail_url }}
      <section>
        <h2>{teamName} / {projectName}</h2>
        <ul>
          <li>
            <img src={thumbnail_url} alt={name} width="50" height="50" />
            {name}
          </li>
        </ul>
      </section>
    {/each}
  {/if}
</main>

<style>
  main {
    font-family: Arial, sans-serif;
    padding: 2rem;
  }

  input {
    margin-right: 1rem;
    padding: 0.5rem;
  }
</style>
