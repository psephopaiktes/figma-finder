// Replace @raycast/api's LocalStorage with browser's localStorage

// Function to get cached data
export async function getCachedData(key: string) {
  const data = localStorage.getItem(key);
  if (data) {
    console.log(`Cache hit for key: ${key}`);
    return JSON.parse(data);
  }
  console.log(`Cache miss for key: ${key}`);
  return undefined;
}

// Function to set cached data
export async function setCachedData(key: string, value: any) {
  const data = JSON.stringify(value);
  localStorage.setItem(key, data);
  console.log(`Cache set for key: ${key}`);
}

// Function to clear cached data
export async function clearCachedData(key: string) {
  localStorage.removeItem(key);
}

export async function getCachedDataWithExpiry(key: string, expiryMs: number) {
  const cached = localStorage.getItem(key);
  if (!cached) {
    console.log(`Cache miss for key: ${key}`);
    return undefined;
  }

  const { value, timestamp } = JSON.parse(cached);
  const now = Date.now();

  if (now - timestamp > expiryMs) {
    console.log(`Cache expired for key: ${key}`);
    localStorage.removeItem(key);
    return undefined;
  }

  console.log(`Cache hit for key: ${key}`);
  return value;
}

export async function setCachedDataWithTimestamp(key: string, value: any) {
  const data = JSON.stringify({ value, timestamp: Date.now() });
  localStorage.setItem(key, data);
  console.log(`Cache set for key: ${key}`);
}
