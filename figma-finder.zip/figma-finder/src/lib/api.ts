import { store } from "../env";

// Function to fetch files from a specific team
export async function fetchTeamFiles(teamId: string) {
  const response = await fetch(
    `https://api.figma.com/v1/teams/${teamId}/files`,
    {
      headers: {
        Authorization: `Bearer ${store.access_token}`,
      },
    }
  );

  if (!response.ok) {
    throw new Error("Failed to fetch Figma files");
  }

  const data = await response.json();
  return data.files; // Assuming the API returns a 'files' array
}

// Function to fetch projects from a specific team
export async function fetchTeamProjects(teamId: string) {
  const response = await fetch(
    `https://api.figma.com/v1/teams/${teamId}/projects`,
    {
      headers: {
        Authorization: `Bearer ${store.access_token}`,
      },
    }
  );

  if (!response.ok) {
    throw new Error("Failed to fetch Figma projects");
  }

  const data = await response.json();
  return data.projects; // Assuming the API returns a 'projects' array
}

// Function to fetch files from a specific project
export async function fetchProjectFiles(projectId: string) {
  const response = await fetch(
    `https://api.figma.com/v1/projects/${projectId}/files`,
    {
      headers: {
        Authorization: `Bearer ${store.access_token}`,
      },
    }
  );

  if (!response.ok) {
    throw new Error("Failed to fetch Figma files");
  }

  const data = await response.json();
  return data.files; // Assuming the API returns a 'files' array
}
