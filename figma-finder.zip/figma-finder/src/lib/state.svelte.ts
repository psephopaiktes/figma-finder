export const state = $state({
  teams: [],
  projects: [],
  files: [],
  selectedTeam: null,
  selectedProject: null,
});
